
public class TestPayRoll {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PayRollManager pm=new PayRollManager();
		pm.getEmployeeSalaryDetails("C:\\Users\\396662\\Desktop\\Emp_file1.txt", "C:\\Users\\396662\\Desktop\\payroll.txt");
	}

}
