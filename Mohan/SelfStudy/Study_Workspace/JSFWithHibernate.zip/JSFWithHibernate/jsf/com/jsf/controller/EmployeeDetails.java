package com.jsf.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import com.general.Exception.RecordNotFoundException;
import com.hibernate.dao.EmployeeDao;
import com.hibernate.entity.Employee;
import com.jsf.javabean.EmployeeBean;

public class EmployeeDetails {
	
	
	private EmployeeBean employeeBean;
	
	private boolean employeeRendered=false;
	
	private List<EmployeeBean> employeeBeanList;
	
	
	public List<EmployeeBean> getEmployeeBeanList() {
		return employeeBeanList;
	}

	public void setEmployeeBeanList(List<EmployeeBean> employeeBeanList) {
		this.employeeBeanList = employeeBeanList;
	}

	
	
	public boolean isEmployeeRendered() {
		return employeeRendered;
	}

	public void setEmployeeRendered(boolean employeeRendered) {
		this.employeeRendered = employeeRendered;
	}

	public EmployeeBean getEmployeeBean() {
		return employeeBean;
	}

	public void setEmployeeBean(EmployeeBean employeeBean) {
		this.employeeBean = employeeBean;
	}

	public String getEmployee()
	{
		List<Employee> empVOList;
		EmployeeBean empBean;
		EmployeeDao empDao=new EmployeeDao();
		
		FacesContext fc=FacesContext.getCurrentInstance();
		EmployeeBean reqBean=(EmployeeBean)fc.getExternalContext().getRequestMap().get("employeeBean");
		//EmployeeDetails empdet=(EmployeeDetails)fc.getExternalContext().getRequestMap().get("employeeDetails");
		
		System.out.println("Employee Controller Bean");
		System.out.println("Emp ID>>>>"+reqBean.getEmpId());
		//System.out.println("Emp Det>>>>"+empdet.getEmployeeBean().getEmpId());
		
		employeeBeanList=new ArrayList<EmployeeBean>();
		try {
			
			empVOList=empDao.getEmployee(employeeBean);
			if(empVOList.size()==0)
				throw new RecordNotFoundException("Employee");
			
			for (Employee empVO : empVOList) {
				if(empVO!=null)
				{
					empBean=new EmployeeBean();
					empBean.setEmpId(empVO.getEmpId());
					empBean.setDesignation(empVO.getDesignation());
					empBean.setEmpname(empVO.getEmpName());
					System.out.println("Empl Name"+empBean.getEmpname());
					employeeBeanList.add(empBean);
					
					//empdet.setEmployeeBeanList(this.employeeBeanList);
					//fc.getExternalContext().getRequestMap().put("employeeDetails", empdet);
				}
			}		
			
			this.employeeRendered=true;
		}
		catch (RecordNotFoundException e) {
			// TODO Auto-generated catch block
			fc.addMessage(null, new FacesMessage("General Message >>>> "+e.getMessage()));
			
			fc.addMessage("empId", new FacesMessage("Specific Message for EMPID"));
			e.printStackTrace();
		}
		
		return "search";
	}
	
	public String updateEmployee()
	{
		System.out.println("updateEmployee");
		FacesContext fc=FacesContext.getCurrentInstance();
		String id=(String)fc.getExternalContext().getRequestParameterMap().get("empid");
		System.out.println("Emp ID>>>>"+id);
		//this.employeeBean=new EmployeeBean();
		this.employeeBean.setEmpId(Integer.valueOf(id));
		//fc.getExternalContext().getRequestMap().put("employeeBean", employeeBean);
		return "update";
	}
	
	public String registerEmployee()
	{
		System.out.println("Register Employee");
		
		FacesContext fc=FacesContext.getCurrentInstance();
		EmployeeBean reqBean=(EmployeeBean)fc.getExternalContext().getRequestMap().get("employeeBean");
		//EmployeeDetails empdet=(EmployeeDetails)fc.getExternalContext().getRequestMap().get("employeeDetails");
		
		System.out.println("Emp Name>>>>"+reqBean.getEmpname());
		
		EmployeeDao empDao=new EmployeeDao();
		
		Employee emp=empDao.register(setbeanToEntity(reqBean));
		fc.addMessage(null, new FacesMessage("Employee Created in DB /\n Generated Employee Id is "));
		reqBean.setEmpId(emp.getEmpId());
		employeeBean=reqBean;
		return "success";
	}
	
	public static Employee setbeanToEntity(EmployeeBean employeeBean)
	{
		Employee emp=new Employee();
		emp.setEmpName(employeeBean.getEmpname());
		emp.setEmpAddress(employeeBean.getAddress());
		emp.setDesignation(employeeBean.getDesignation());
		emp.setLandLine(employeeBean.getLandlineNo());
		emp.setMobile(employeeBean.getMobileNo());
		return emp; 
	}
}
