package com.cognizant.rif.constants;

public final class RIFInputConstants {

	public static final String ERROR_PROPERTY="/properties/ErrorMessagesfinal.properties";
	public static final String ERROR_TO_RULE_PATH="/properties/Error-Rule.properties";
	public static final String SOURCE_CODE_ROOT_DIR="C:\\Users\\396662\\396662_MT_GAP_OF_Dev1_1\\";
	public static final String RULE_EXTRACTION_FOLDER="RULE_EXTRACTION";
	public static final String OUTPUT_POJO_FILEPATH="D:\\RIF\\rules";
	public static final String OUTPUT_PATTERN_FILEPATH="D:\\Rule Extract\\";
}
