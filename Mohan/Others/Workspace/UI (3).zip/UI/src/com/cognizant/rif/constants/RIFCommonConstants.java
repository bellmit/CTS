package com.cognizant.rif.constants;

public class RIFCommonConstants {
	public static final String PROPERTY_EXTENSION=".properties";

}
